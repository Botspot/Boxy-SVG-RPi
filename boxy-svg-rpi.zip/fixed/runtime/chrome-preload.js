
// @copyright
//   © 2012-2020 Jarosław Foksa

"use strict";

(function() {
  window.argv = [];
})();
